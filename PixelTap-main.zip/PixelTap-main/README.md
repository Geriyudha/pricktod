<h1 align="center">Auto Claim PixelTap by Pixelverse (DWYOR)</h1>
<h3 align="center">How To Use (DWYOR)</h3>

- https://t.me/pixelversexyzbot Start The Bot

- git clone **https://github.com/monteksz/PixelTap**

- cd PixelTap

- pip install request

- python main.py

- Set Initdata

- **DONE**

- **Here To get Initdata and Tg-Id**
<img align="center" src="https://github.com/monteksz/PixelTap/blob/main/Data.png">

- **Result**

<img align="center" src="https://github.com/monteksz/PixelTap/blob/main/SS.png">

<h3 align="left">Languages</h3>
<p align="left"> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> </p>
